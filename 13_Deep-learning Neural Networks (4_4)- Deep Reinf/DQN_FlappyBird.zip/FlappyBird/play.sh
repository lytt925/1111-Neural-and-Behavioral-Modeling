# play flappy bird with pretrained model
# you canchange `model_best.pth.tar` to your pretrained model file name 
python main.py\
    --weight model_best.pth.tar\
    --cuda   # uncomment when gpu is available
